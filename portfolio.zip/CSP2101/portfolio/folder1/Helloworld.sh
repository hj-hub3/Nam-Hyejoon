#!/bin/bash
#Nam Hyejoon (10512830)

echo "Hello world!"
exit 0
