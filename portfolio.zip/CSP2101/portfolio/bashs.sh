#!/bin/bash
# Nam Hyejoon (10512830)

read -p "type the name of the folder you would like to create:" folderName
mkdir "$folderName"
