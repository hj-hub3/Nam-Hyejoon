#!/bin/bash
 echo "Hi there!"
 exit 0 
