# first shell script.
# A shell script contains 
# a list of bash commands to be executed 
#in order.

#!/bin/bash
echo "Hi there!"
exit 0