#!/bin/bash

printError()
{
    echo -e "\033[31mERROR:\033[0m $1"
}